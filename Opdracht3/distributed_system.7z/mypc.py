# Copyright (c) 2019 by Elmer Hoeksema
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# The views and conclusions contained in the software and documentation are those
# of the authors and should not be interpreted as representing official policies,
# either expressed or implied.

import threading
import mytaskidle
import time
import random

DEBUG                 = False
RAM_SIZE              = 1000
CACHE_PENALTY_TIME    = 1
RAM_PENALTY_TIME      = 4
NETWORK_PENALTY_TIME  = 10
CLOCK_INTERVAL_IN_SEC = 0.1

class MyPC(threading.Thread):
    def __init__(self, pc_id, core_ready_semaphore):
        threading.Thread.__init__(self)
        self.pc_id = pc_id
        self.core_dictionary = {}
        self.cache_dictionary_per_core_array = [{}, {}]
        self.ram_array = []
        for address in range(RAM_SIZE):
            self.ram_array.append(0)
        # Semaphore to protect RAM access
        self.ram_lock = threading.Lock()
        self.clock_counter = 0
        self.core_utilization_array = []
        self.cache_utilization_array = []
        random.seed()
        # Semaphore to simulate synchronous network connection on 1000 ports
        self.network_data_available_to_read_array = []
        for port in range(1000):
            self.network_data_available_to_read_array.append(threading.Semaphore(0))
        # Flag to keep PC running
        self.keep_running = True
        # Free cores, all initialized to free
        free_cores_array = [True, True, True, True]
        # Semaphore to protect free_cores_array variable
        free_cores_array_lock = threading.Lock()
        # Create 2 sockets
        for socket_id in range(2):
            # Create 2 sockets per core
            for core_id in range(2):
                self.core_dictionary[(socket_id, core_id)] = MyCore(self, socket_id, core_id, core_ready_semaphore)

    # Connect PC to network
    def add_network(self, network):
        self.network = network
        network.connect(self)
      
    # Read from network
    def net_read(self, core, port):
        # port must be in 0 to 9 range, check for out of bound
        assert ((port >= 0) and (port < 1000)), "Port " + str(port) + " is out of range, must be 0 to 999"
        # Wait until data is available
        self.network_data_available_to_read_array[port].acquire()
        # Pentalty for network access is NETWORK_PENALTY_TIME waitstates
        core.penalty_wait_states = core.penalty_wait_states + NETWORK_PENALTY_TIME
        return self.network.read(self.pc_id, port)

    # Write to network
    def net_write(self, core, destination_pc_id, port, data):
        # port must be in 0 to 9 range, check for out of bound
        assert ((port >= 0) and (port < 1000)), "Port " + str(port) + " is out of range, must be 0 to 999"
        # Pentalty for network access is NETWORK_PENALTY_TIME waitstates
        core.penalty_wait_states = core.penalty_wait_states + NETWORK_PENALTY_TIME
        self.network.write(destination_pc_id, port, data)

    # Add data element to cache
    def add_to_cache(self, socket, address, data):
        # Max cache size is 10 data elements
        if (len(self.cache_dictionary_per_core_array[socket]) >= 10):
            minimal_clock = 999999999
            remove_address = -1
            for address in self.cache_dictionary_per_core_array[socket]:
                # Check if cache element is least recent used
                if(self.cache_dictionary_per_core_array[socket][address][1] < minimal_clock):
                    minimal_clock = self.cache_dictionary_per_core_array[socket][address][1]
                    remove_address = address
            # Remove least recent used cache element
            assert (address >= 0), "Cache could not identify element to remove"
            del self.cache_dictionary_per_core_array[socket][address]
        # Add data element to cache_dictionary
        self.cache_dictionary_per_core_array[socket][address] = (data, self.clock_counter)

    # Read from memory
    def mem_read(self, core, address):
        if DEBUG:
            print("mem_read PC " + "{:3d}".format(self.pc_id) + ", socket " + str(core.socket_id) + ", core " + str(core.core_id) + ", address " + "{:3d}".format(address) + ", cache " + str(self.cache_dictionary_per_core_array))
        # Protect RAM from concurrent access
        self.ram_lock.acquire()
        # Register memory access
        core.memory_access_counter = core.memory_access_counter + 1
        # Check if memory in cache
        if address in self.cache_dictionary_per_core_array[core.socket_id]:
            # Register cache hit
            core.cache_hit_counter = core.cache_hit_counter + 1
            # Pentalty for cache access is CACHE_PENALTY_TIME waitstates
            core.penalty_wait_states = core.penalty_wait_states + CACHE_PENALTY_TIME
            # Update last used clock for cache item
            self.cache_dictionary_per_core_array[core.socket_id][address] = (self.cache_dictionary_per_core_array[core.socket_id][address][0], self.clock_counter)
            # Use data element from cache
            data = self.cache_dictionary_per_core_array[core.socket_id][address][0]
            self.ram_lock.release()
            if DEBUG:
                print("mem_read PC " + "{:3d}".format(self.pc_id) + ", socket " + str(core.socket_id) + ", core " + str(core.core_id) + ", address " + "{:3d}".format(address) + " data: " + str(data) + ", cache " + str(self.cache_dictionary_per_core_array))
            return data
        else:
            # RAM size is RAM_SIZE data elements, check for out of bound
            assert ((address >= 0) and (address < RAM_SIZE)), "Address " + str(address) + " is out of range, RAM size is " + str(RAM_SIZE)
            # Add data element to cache
            self.add_to_cache(core.socket_id, address, self.ram_array[address])
            # Pentalty for RAM access is RAM_PENALTY_TIME waitstates
            core.penalty_wait_states = core.penalty_wait_states + RAM_PENALTY_TIME
            data = self.ram_array[address]
            self.ram_lock.release()
            if DEBUG:
                print("mem_read PC " + "{:3d}".format(self.pc_id) + ", socket " + str(core.socket_id) + ", core " + str(core.core_id) + ", address " + "{:3d}".format(address) + " data: " + str(data) + ", cache " + str(self.cache_dictionary_per_core_array))
            return data

    # Write to memory
    def mem_write(self, core, address, data):
        if DEBUG:
            print("mem_write PC " + "{:3d}".format(self.pc_id) + ", socket " + str(core.socket_id) + ", core " + str(core.core_id) + ", address " + "{:3d}".format(address) + " data: " + str(data) + ", cache " + str(self.cache_dictionary_per_core_array))
        # Protect RAM from concurrent access
        self.ram_lock.acquire()
        # Register memory access
        core.memory_access_counter = core.memory_access_counter + 1
        # Check if memory in cache
        if address in self.cache_dictionary_per_core_array[core.socket_id]:
            # Register cache hit
            core.cache_hit_counter = core.cache_hit_counter + 1
            # Pentalty for cache access is CACHE_PENALTY_TIME waitstates
            core.penalty_wait_states = core.penalty_wait_states + CACHE_PENALTY_TIME
            # Update data element in cache
            self.cache_dictionary_per_core_array[core.socket_id][address] = (data, self.clock_counter)
            # Update data element in RAM
            self.ram_array[address] = data
        else:
            # RAM size is RAM_SIZE data elements, check for out of bound
            assert ((address >= 0) and (address < RAM_SIZE)), "Address " + str(address) + " is out of range, RAM size is " + str(RAM_SIZE)
            # Add data element to cache
            self.add_to_cache(core.socket_id, address, data)
            # Update data element in RAM
            self.ram_array[address] = data
            # Pentalty for RAM access is RAM_PENALTY_TIME waitstates
            core.penalty_wait_states = core.penalty_wait_states + RAM_PENALTY_TIME
        self.ram_lock.release()
    
    # Create thread for each core and assign task scheduler
    def run(self):
        # Start all cores
        for socket_id in range(2):
            for core_id in range(2):
                self.core_dictionary[(socket_id, core_id)].start()
        # Keep running until stopped from main
        while self.keep_running:
            # Increase clock counter
            self.clock_counter = self.clock_counter + 1
            # Pulse clock for all cores
            for socket_id in range(2):
                for core_id in range(2):
                    # Only release cores in Ready state (non in the process of executing an instruction)
                    self.core_dictionary[(socket_id, core_id)].ready_lock.acquire()
                    if self.core_dictionary[(socket_id, core_id)].ready:
                        self.core_dictionary[(socket_id, core_id)].clock.release()
                    self.core_dictionary[(socket_id, core_id)].ready_lock.release()
            # Wait clock pulse interval
            time.sleep(CLOCK_INTERVAL_IN_SEC)
        # When finished, calculate core utilization
        for socket_id in range(2):
            for core_id in range(2):
                if(self.clock_counter > 0):
                    self.core_utilization_array.append(round(self.core_dictionary[(socket_id, core_id)].busy_counter / self.clock_counter * 100, 2))
                else:
                    self.core_utilization_array.append(0)
                if(self.core_dictionary[(socket_id, core_id)].memory_access_counter > 0):
                    self.cache_utilization_array.append(round(self.core_dictionary[(socket_id, core_id)].cache_hit_counter / self.core_dictionary[(socket_id, core_id)].memory_access_counter * 100, 2))
                else:
                    self.cache_utilization_array.append(-1)
        # Kill all cores
        for socket_id in range(2):
            for core_id in range(2):
                self.core_dictionary[(socket_id, core_id)].keep_running = False
                self.core_dictionary[(socket_id, core_id)].clock.release()
                self.core_dictionary[(socket_id, core_id)].join()

class MyCore(threading.Thread):
    # Instruction set:
    # load_a            VALUE         load register A with VALUE
    # add_a             VALUE         add VALUE to register A
    # sub_a             VALUE         subtract VALUE from register A
    # mul_a             VALUE         multiply register A with VALUE
    # add_mem           ADDRESS       add memory in ADDRESS to register A
    # sub_mem           ADDRESS       subtract memory in ADDRESS from register A
    # mul_mem           ADDRESS       multiply register A with memory in ADDRESS
    # add_i                           add memory in address register I to register A
    # sub_i                           subtract memory in address register I from register A
    # mul_i                           multiply register A with memory in address register I
    # store_a           ADDRESS       store register A into memory at ADDRESS
    # read_a            ADDRESS       read register A from memory at ADDRESS
    # store_i                         store register A into memory at address in register I
    # read_i                          read register A from memory at address in register I
    # net_write_a       PC_ID  PORT   write register A to network PORT of PC_ID
    # net_read_a        PORT          read register A from network PORT
    # net_write_i       PORT          write register A to network PORT of pc register I
    # net_reg           VALUE         register this pc id as VALUE in network directory system
    # net_lookup        VALUE         lookup VALUE in network directory system and store pc id in register I
    # random_a          VALUE         load register A with random value in the range from 0 to VALUE (VALUE not included)
    # swap                            swap register A and register I
    # jump              NUMBER        jump to instruction NUMBER
    # jump_on_zero      NUMBER        jump to instruction NUMBER if result of last register A change was zero
    # jump_on_negative  NUMBER        jump to instruction NUMBER if result of last register A change was negative
    # out_a                           print register A to output
    # nop                             do nothing
    # end                             end task

    def __init__(self, pc, socket_id, core_id, core_ready_semaphore):
        threading.Thread.__init__(self)
        self.pc = pc
        self.socket_id = socket_id
        self.core_id = core_id
        # Default task is idle
        self.task = mytaskidle.MyTaskIdle()
        # Default core has no task assigned to it
        self.task_assigned = False
        # Semaphore to protect task and task_assigned variable
        self.task_lock = threading.Lock()
        # Initialize register a
        self.register_a = 0
        # Initialize register i
        self.register_i = 0
        # Initialize program counter
        self.program_counter = 0
        # Initialize zero flag
        self.zero_flag = True
        # Initialize negative flag
        self.negative_flag = False
        # Initialize use counter
        self.busy_counter = 0
        # Initialize memory access counter
        self.memory_access_counter = 0
        # Initialize cache hit counter
        self.cache_hit_counter = 0
        # Semaphore to simulate clock
        self.clock = threading.Semaphore(0)
        # Core is Ready to execute next instruction
        self.ready = True
        # Semaphore to protect ready variable
        self.ready_lock = threading.Lock()
        # Penalty wait states for long instructions
        self.penalty_wait_states = 0
        # Flag to keep thread (core) running
        self.keep_running = True
        # Semaphore from main to wait for cores to report free
        self.core_ready_semaphore = core_ready_semaphore

    # Main for core thread
    def run(self):
        # Report core free
        self.core_ready_semaphore.release()
        while self.keep_running:
            self.clock.acquire()
            if (self.penalty_wait_states > 0):
                self.penalty_wait_states = self.penalty_wait_states - 1
            else:
                self.ready_lock.acquire()
                self.ready = False
                self.ready_lock.release()
                self.task_lock.acquire()
                instruction = self.task.get_instruction(self.program_counter)
                self.task_lock.release()
                if (DEBUG and (instruction[0] != "nop")):
                    print("instruction PC " + "{:3d}".format(self.pc.pc_id) + ", socket " + str(self.socket_id) + ", core " + str(self.core_id) + ", program_counter " + "{:3d}".format(self.program_counter) + ", zero_flag " + str(self.zero_flag) + ", negative_flag " + str(self.negative_flag) + ", instruction: " + str(instruction))
                # Increase program counter and reset at 1000
                self.program_counter = self.program_counter + 1
                if(self.program_counter >= 1000):
                    self.program_counter = 0
                self.busy_counter = self.busy_counter + 1
                if (instruction[0] == "load_a"):
                    self.register_a = instruction[1]
                elif (instruction[0] == "add_a"):
                    self.register_a = self.register_a + instruction[1]
                    self.set_flags()
                elif (instruction[0] == "sub_a"):
                    self.register_a = self.register_a - instruction[1]
                    self.set_flags()
                elif (instruction[0] == "mul_a"):
                    self.register_a = self.register_a * instruction[1]
                    self.set_flags()
                elif (instruction[0] == "add_mem"):
                    self.register_a = self.register_a + self.pc.mem_read(self, instruction[1])
                    self.set_flags()
                elif (instruction[0] == "sub_mem"):
                    self.register_a = self.register_a - self.pc.mem_read(self, instruction[1])
                    self.set_flags()
                elif (instruction[0] == "mul_mem"):
                    self.register_a = self.register_a * self.pc.mem_read(self, instruction[1])
                    self.set_flags()
                elif (instruction[0] == "add_i"):
                    self.register_a = self.register_a + self.pc.mem_read(self, self.register_i)
                    self.set_flags()
                elif (instruction[0] == "sub_i"):
                    self.register_a = self.register_a - self.pc.mem_read(self, self.register_i)
                    self.set_flags()
                elif (instruction[0] == "mul_i"):
                    self.register_a = self.register_a * self.pc.mem_read(self, self.register_i)
                    self.set_flags()
                elif (instruction[0] == "store_a"):
                    self.pc.mem_write(self, instruction[1], self.register_a)
                elif (instruction[0] == "read_a"):
                    self.register_a = self.pc.mem_read(self, instruction[1])
                    self.set_flags()
                elif (instruction[0] == "store_i"):
                    self.pc.mem_write(self, self.register_i, self.register_a)
                elif (instruction[0] == "read_i"):
                    self.register_a = self.pc.mem_read(self, self.register_i)
                    self.set_flags()
                elif (instruction[0] == "net_write_a"):
                    self.pc.net_write(self, instruction[1], instruction[2], self.register_a)
                elif (instruction[0] == "net_read_a"):
                    self.register_a = self.pc.net_read(self, instruction[1])
                    self.set_flags()
                elif (instruction[0] == "net_write_i"):
                    self.pc.net_write(self, self.register_i, instruction[1], self.register_a)
                elif (instruction[0] == "net_reg"):
                    self.pc.network.register(instruction[1], self.pc.pc_id)
                elif (instruction[0] == "net_lookup"):
                    self.register_i = self.pc.network.lookup(instruction[1])
                elif (instruction[0] == "random_a"):
                    self.register_a = random.randrange(instruction[1])
                    self.set_flags()
                elif (instruction[0] == "swap"):
                    a = self.register_a
                    self.register_a = self.register_i
                    self.register_i = a
                    self.set_flags()
                elif (instruction[0] == "jump"):
                    self.program_counter = instruction[1]
                elif (instruction[0] == "jump_on_zero"):
                    if self.zero_flag:
                        self.program_counter = instruction[1]
                elif (instruction[0] == "jump_on_negative"):
                    if self.negative_flag:
                        self.program_counter = instruction[1]
                elif (instruction[0] == "out_a"):
                    print("PC " + "{:3d}".format(self.pc.pc_id) + ", socket " + str(self.socket_id) + ", core " + str(self.core_id) + ", output: " + str(self.register_a))
                elif (instruction[0] == "nop"):
                    # nop instruction does not count as core busy time
                    self.busy_counter = self.busy_counter - 1
                elif (instruction[0] == "end"):
                    self.task_lock.acquire()
                    self.task = mytaskidle.MyTaskIdle()
                    self.task_assigned = False
                    self.program_counter = 0
                    self.task_lock.release()
                    # Report core free
                    self.core_ready_semaphore.release()
                self.ready_lock.acquire()
                self.ready = True
                self.ready_lock.release()

    # Set flags
    def set_flags(self):
        if (self.register_a == 0):
            self.zero_flag = True
        else:
            self.zero_flag = False
        if (self.register_a < 0):
            self.negative_flag = True
        else:
            self.negative_flag = False

    # Assign task to core
    def run_task(self, task):
        self.task_lock.acquire()
        self.task = task
        self.task_assigned = True
        self.program_counter = 0
        self.task_lock.release()

    # Check if core has task assigned
    def has_task_assigned(self):
        self.task_lock.acquire()
        task_assigned = self.task_assigned
        self.task_lock.release()
        return task_assigned
