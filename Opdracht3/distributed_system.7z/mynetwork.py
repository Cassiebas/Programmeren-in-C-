# Copyright (c) 2019 by Elmer Hoeksema
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# The views and conclusions contained in the software and documentation are those
# of the authors and should not be interpreted as representing official policies,
# either expressed or implied.

import threading

class MyNetwork():
    def __init__(self):
        self.node_dictionary      = {}
        self.data_dictionary      = {}
        self.directory_dictionary = {}
        # Semaphore to protect data_dictionary
        self.data_dictionary_lock = threading.Lock()
        # Semaphore to simulate registration of 1000 network locations
        self.value_registered_in_directory_array = []
        for port in range(1000):
            self.value_registered_in_directory_array.append(threading.Semaphore(0))

    # Register PC as node in network
    def connect(self, pc):
        self.node_dictionary[pc.pc_id] = pc
    
    # Register value as pc id in network directory
    def register(self, value, pc_id):
        # value must be in 0 to 999 range, check for out of bound
        assert ((value >= 0) and (value < 1000)), "Network location " + str(value) + " is out of range, must be 0 to 999"
        self.directory_dictionary[value] = pc_id
        self.value_registered_in_directory_array[value].release()
    
    # Lookup value in network directory
    def lookup(self, value):
        # value must be in 0 to 999 range, check for out of bound
        assert ((value >= 0) and (value < 1000)), "Network location " + str(value) + " is out of range, must be 0 to 999"
        self.value_registered_in_directory_array[value].acquire()
        return self.directory_dictionary[value]
    
    # Read from node
    def read(self, calling_pc_id, port):
        self.data_dictionary_lock.acquire()
        # Look for packet from remote_pc_id to calling_pc_id on port
        if (calling_pc_id, port) in self.data_dictionary:
            data = self.data_dictionary[(calling_pc_id, port)].pop(0)
            if len(self.data_dictionary[(calling_pc_id, port)]) == 0:
                del self.data_dictionary[(calling_pc_id, port)]
            self.data_dictionary_lock.release()
            return data
        else:
            self.data_dictionary_lock.release()
            raise "Network error: no data available from " + str(remote_pc_id) + " for " + str(calling_pc_id) + " on port " + str(port)

    # Write to node
    def write(self, remote_pc_id, port, data):
        self.data_dictionary_lock.acquire()
        # store data as packet in dictionary
        if (remote_pc_id, port) not in self.data_dictionary:
            self.data_dictionary[(remote_pc_id, port)] = []
        self.data_dictionary[(remote_pc_id, port)].append(data)
        self.data_dictionary_lock.release()
        # release receiving pc to collect data
        self.node_dictionary[remote_pc_id].network_data_available_to_read_array[port].release()
