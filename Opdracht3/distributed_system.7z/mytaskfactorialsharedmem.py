# Copyright (c) 2019 by Elmer Hoeksema
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# The views and conclusions contained in the software and documentation are those
# of the authors and should not be interpreted as representing official policies,
# either expressed or implied.

class MyTaskFactorialSharedMem():
    def __init__(self, task_id, n):
        self.task_id = task_id
        self.n       = n
        self.instruction_dictionary = {}
        self.set_code(0)

    def set_core(self, core):
        # Memory map start at 150 + core * 5, reserve 5
        # Memory reserved for this task on 4 cores is 150-169
        # Core 0 = 150-154
        # Core 1 = 155-159
        # Core 2 = 160-164
        # Core 3 = 165-169
        self.set_code(150 + (core * 5))

    def set_code(self, start_address):
        self.instruction_dictionary[0] = ("load_a", self.n)
        self.instruction_dictionary[1] = ("store_a", start_address)
        self.instruction_dictionary[2] = ("sub_a", 1)
        self.instruction_dictionary[3] = ("jump_on_zero", 10)
        self.instruction_dictionary[4] = ("store_a", start_address + 1)
        self.instruction_dictionary[5] = ("read_a", start_address)
        self.instruction_dictionary[6] = ("mul_mem", start_address + 1)
        self.instruction_dictionary[7] = ("store_a", start_address)
        self.instruction_dictionary[8] = ("read_a", start_address + 1)
        self.instruction_dictionary[9] = ("jump", 2)
        self.instruction_dictionary[10] = ("read_a", start_address)
        self.instruction_dictionary[11] = ("out_a", None)
        self.instruction_dictionary[12] = ("end", None)

    def get_instruction(self, instruction_number):
        return self.instruction_dictionary[instruction_number]




