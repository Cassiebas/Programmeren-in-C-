# Copyright (c) 2019 by Elmer Hoeksema
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# The views and conclusions contained in the software and documentation are those
# of the authors and should not be interpreted as representing official policies,
# either expressed or implied.

class MyTaskNetSend():
    def __init__(self, task_id, n):
        self.task_id = task_id
        self.n       = n
        self.instruction_dictionary = {}
        self.instruction_dictionary[0] = ("load_a", n)          # store argument in register A
        self.instruction_dictionary[1] = ("net_lookup", 445)    # lookup network node id 445 in network directory and store pc id in register I
        self.instruction_dictionary[2] = ("net_write_i", 6)     # write register A to port 6 of pc in register I
        self.instruction_dictionary[3] = ("swap", None)         # move pc id from register I into register A
        self.instruction_dictionary[4] = ("out_a", None)        # print value stored in A
        self.instruction_dictionary[5] = ("end", None)

    def set_core(self, core):
        pass

    def get_instruction(self, instruction_number):
        return self.instruction_dictionary[instruction_number]




