# Copyright (c) 2019 by Elmer Hoeksema
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# The views and conclusions contained in the software and documentation are those
# of the authors and should not be interpreted as representing official policies,
# either expressed or implied.

import mypc
import mynetwork
import mytaskfactorial
import mytaskmemadd
import mytaskfactorialsharedmem
import mytaskmemaddsharedmem
import mytasknetsend
import mytasknetreceive
import threading
import time

DEBUG                = False
PC_COUNT             = 100
SCAN_INTERVAL_IN_SEC = 1

# Semaphore to wait for cores to report free
core_ready_semaphore = threading.Semaphore(0)

# Create set of PC's
pc_array = []
for pc_id in range(PC_COUNT):
    pc_array.append(mypc.MyPC(pc_id, core_ready_semaphore))

# Create network
network = mynetwork.MyNetwork()

# Connect PC's to network
for pc in pc_array:
    pc.add_network(network)

# Create tasks - 10 sample factorial tasks and 10 sample add memory items tasks
task_array = []
for task_id in range(10):
    task_array.append(mytaskfactorialsharedmem.MyTaskFactorialSharedMem(task_id, 50))
for task_id in range(10, 20):
    task_array.append(mytaskmemaddsharedmem.MyTaskMemAddSharedMem(task_id, 100))

# Start all PC's
for pc in pc_array:
    pc.start()

# Dispatch sample simple tasks that must run on socket 0 and core 0
# because they do not use a memory map for concurrent processing
for task_id in range(10):
    # Wait for core to report free
    core_ready_semaphore.acquire()
    # Dispatch on pc 70-79
    pc_array[70 + task_id].core_dictionary[0, 0].run_task(mytaskfactorial.MyTaskFactorial(100 + task_id, 50))
    if DEBUG:
        print("Dispatch task " + "{:3d}".format(100 + task_id) + " on PC " + "{:3d}".format(70 + task_id) + ", socket " + "{:3d}".format(0) + ", core " + "{:3d}".format(0))
for task_id in range(10):
    # Wait for core to report free
    core_ready_semaphore.acquire()
    # Dispatch on pc 80-89
    pc_array[80 + task_id].core_dictionary[0, 0].run_task(mytaskmemadd.MyTaskMemAdd(110 + task_id, 100))
    if DEBUG:
        print("Dispatch task " + "{:3d}".format(110 + task_id) + " on PC " + "{:3d}".format(80 + task_id) + ", socket " + "{:3d}".format(0) + ", core " + "{:3d}".format(0))

# Dispatch sample network tasks on pc 98 and 99
# Wait for core to report free
core_ready_semaphore.acquire()
pc_array[98].core_dictionary[0, 0].run_task(mytasknetsend.MyTaskNetSend(200, 1234))
if DEBUG:
    print("Dispatch task " + "{:3d}".format(200) + " on PC " + "{:3d}".format(98) + ", socket " + "{:3d}".format(0) + ", core " + "{:3d}".format(0))
# Wait for core to report free
core_ready_semaphore.acquire()
pc_array[99].core_dictionary[0, 0].run_task(mytasknetreceive.MyTaskNetReceive(201))
if DEBUG:
    print("Dispatch task " + "{:3d}".format(201) + " on PC " + "{:3d}".format(99) + ", socket " + "{:3d}".format(0) + ", core " + "{:3d}".format(0))

# Dispatch tasks to cores
# Reverse task array because last task is popped first
task_array = task_array[::-1]
while (len(task_array) > 0):
    # Wait for core to report free
    core_ready_semaphore.acquire()
    # Search for free core (pc_id, socket_id, core_id)
    free_core = (-1, -1, -1)
    pc_id = 0
    socket_id = 0
    core_id = 0
    # Search first available core
    while((pc_id < PC_COUNT) and (free_core == (-1, -1, -1))):
        if (not pc_array[pc_id].core_dictionary[(socket_id, core_id)].has_task_assigned()):
            free_core = (pc_id, socket_id, core_id)
        core_id = core_id + 1
        if(core_id > 1):
            socket_id=socket_id + 1
            core_id = 0
        if(socket_id > 1):
            pc_id = pc_id + 1
            socket_id = 0
            core_id = 0
    # Check for error in detecting free core
    assert (free_core != (-1, -1, -1)), "Free core detection error"
    task = task_array.pop()
    if DEBUG:
        print("Dispatch task " + "{:3d}".format(task.task_id) + " on PC " + "{:3d}".format(free_core[0]) + ", socket " + "{:3d}".format(free_core[1]) + ", core " + "{:3d}".format(free_core[2]))
    # Notify task of core used so it can use correct location im memory map
    task.set_core((socket_id * 2) + core_id)
    pc_array[free_core[0]].core_dictionary[(free_core[1], free_core[2])].run_task(task)

# Wait for all cores to finish running tasks
all_cores_done = False
while (not all_cores_done):
    all_cores_done = True
    for pc in pc_array:
        for socket_id in range(2):
            for core_id in range(2):
                if (pc_array[pc.pc_id].core_dictionary[(socket_id, core_id)].has_task_assigned()):
                    all_cores_done = False
                    if DEBUG:
                        print("Waiting for running task on PC " + "{:3d}".format(pc.pc_id) + ", socket " + "{:3d}".format(socket_id) + ", core " + "{:3d}".format(core_id))
    # Wait scan interval
    time.sleep(SCAN_INTERVAL_IN_SEC)

# Stop all PC's and calculate efficiency
for pc in pc_array:
    pc.keep_running = False
core_total = 0
cache_total = 0
cache_core_total = 0
for pc in pc_array:
    # Wait for PC to finish executing
    pc.join()
    out_text = "Core efficiency PC " + "{:3d}".format(pc.pc_id) + ": " + "{:6.2f}".format(pc.core_utilization_array[0]) + "% "
    out_text = out_text + "{:6.2f}".format(pc.core_utilization_array[1]) + "% " + "{:6.2f}".format(pc.core_utilization_array[2]) + "% " + "{:6.2f}".format(pc.core_utilization_array[3]) + "%   cache efficiency "
    if(pc.cache_utilization_array[0] == -1):
        out_text = out_text + "   N/A  "
    else:
        out_text = out_text + "{:6.2f}".format(pc.cache_utilization_array[0]) + "% "
        cache_total = cache_total + pc.cache_utilization_array[0]
        cache_core_total = cache_core_total + 1
    if(pc.cache_utilization_array[1] == -1):
        out_text = out_text + "   N/A  "
    else:
        out_text = out_text + "{:6.2f}".format(pc.cache_utilization_array[1]) + "% "
        cache_total = cache_total + pc.cache_utilization_array[1]
        cache_core_total = cache_core_total + 1
    if(pc.cache_utilization_array[2] == -1):
        out_text = out_text + "   N/A  "
    else:
        out_text = out_text + "{:6.2f}".format(pc.cache_utilization_array[2]) + "% "
        cache_total = cache_total + pc.cache_utilization_array[2]
        cache_core_total = cache_core_total + 1
    if(pc.cache_utilization_array[3] == -1):
        out_text = out_text + "   N/A"
    else:
        out_text = out_text + "{:6.2f}".format(pc.cache_utilization_array[3]) + "%"
        cache_total = cache_total + pc.cache_utilization_array[3]
        cache_core_total = cache_core_total + 1
    print(out_text)
    core_total = core_total + pc.core_utilization_array[0] + pc.core_utilization_array[1] + pc.core_utilization_array[2] + pc.core_utilization_array[3]

out_text = "System core efficiency " + str(round(core_total / (len(pc_array) * 4), 2)) + "% system cache efficiency "
if(cache_core_total > 0):
    out_text = out_text + str(round(cache_total / cache_core_total, 2)) + "%"
else:
    out_text = out_text + "N/A"
print(out_text)
