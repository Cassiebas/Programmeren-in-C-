# Copyright (c) 2019 by Elmer Hoeksema
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# The views and conclusions contained in the software and documentation are those
# of the authors and should not be interpreted as representing official policies,
# either expressed or implied.

class MyTaskMemAddSharedMem():
    def __init__(self, task_id, n):
        self.task_id = task_id
        self.n       = n
        self.start_address = 0
        self.instruction_dictionary = {}
        self.set_code(0)

    def set_core(self, core):
        # Memory map start at 200 + core * 150, reserve 150
        # Memory reserved for this task on 4 cores is 200-799
        # Core 0 = 200-349
        # Core 1 = 350-499
        # Core 2 = 500-649
        # Core 3 = 650-799
        self.set_code(200 + (core * 150))

    def set_code(self, start_address):
        self.instruction_dictionary[0] = ("load_a", self.n)
        self.instruction_dictionary[1] = ("store_a", start_address)
        self.instruction_dictionary[2] = ("store_a", start_address + 1)
        self.instruction_dictionary[3] = ("load_a", start_address + 10)
        self.instruction_dictionary[4] = ("swap", None)
        self.instruction_dictionary[5] = ("random_a", 100)
        self.instruction_dictionary[6] = ("add_a", 1)
        self.instruction_dictionary[7] = ("store_i", None)
        self.instruction_dictionary[8] = ("swap", None)
        self.instruction_dictionary[9] = ("add_a", 1)
        self.instruction_dictionary[10] = ("swap", None)
        self.instruction_dictionary[11] = ("read_a", start_address + 1)
        self.instruction_dictionary[12] = ("sub_a", 1)
        self.instruction_dictionary[13] = ("jump_on_zero", 16)
        self.instruction_dictionary[14] = ("store_a", start_address + 1)
        self.instruction_dictionary[15] = ("jump", 5)
        self.instruction_dictionary[16] = ("read_a", start_address)
        self.instruction_dictionary[17] = ("sub_a", 1)
        self.instruction_dictionary[18] = ("store_a", start_address + 1)
        self.instruction_dictionary[19] = ("load_a", start_address + 10)
        self.instruction_dictionary[20] = ("swap", None)
        self.instruction_dictionary[21] = ("read_i", None)
        self.instruction_dictionary[22] = ("swap", None)
        self.instruction_dictionary[23] = ("add_a", 1)
        self.instruction_dictionary[24] = ("swap", None)
        self.instruction_dictionary[25] = ("add_i", None)
        self.instruction_dictionary[26] = ("store_a", start_address + 2)
        self.instruction_dictionary[27] = ("read_a", start_address + 1)
        self.instruction_dictionary[28] = ("sub_a", 1)
        self.instruction_dictionary[29] = ("jump_on_zero", 33)
        self.instruction_dictionary[30] = ("store_a", start_address + 1)
        self.instruction_dictionary[31] = ("read_a", start_address + 2)
        self.instruction_dictionary[32] = ("jump", 22)
        self.instruction_dictionary[33] = ("read_a", start_address + 2)
        self.instruction_dictionary[34] = ("out_a", None)
        self.instruction_dictionary[35] = ("end", None)

    def get_instruction(self, instruction_number):
        return self.instruction_dictionary[instruction_number]



